#include<iostream>
#include<stdio.h>
#include<string.h>
#include<ios>
#include<limits>
#include<conio.h>
#include<math.h>
#include<fstream>
using namespace std;
ifstream fin;
ofstream fout;
fstream fio;
int i,n;

class registration {
		string nou,un,passw,Email,doj;
	public:
		void userprofile() {
			ofstream fout;
			fout.open("Register.txt",ios::app);
			cout<<"Name of user:"<<endl;
			cin.ignore();
			getline(cin,nou);
			cout<<"User Name:"<<endl;
			getline(cin,un);
			cout<<"User password:"<<endl;
			getline(cin,passw);
			cout<<"Email:"<<endl;
			getline(cin,Email);
			cout<<"Date of joining:"<<endl;
			getline(cin,doj);
			fout<<nou<<"\t"<<un<<"\t"<<passw<<"\t"<<Email<<"\t"<<doj<<"\n";
			fout.close();
		}
		void deleteuser() {
			string deleteline;
			string line;
			ifstream fin;
			fin.open("Register.txt");
			ofstream temp;
			temp.open("Temp2.txt");
			cout << "Enter user name to remove:";
			cin >> deleteline;
			while (getline(fin,line)) {
				size_t pos=line.find("\t");
				if(line.substr(0,pos).compare(deleteline)!=0) {
					cout<<"abc";
					temp<<line<<endl;
				}
			}
			fin.close();
			temp.close();
			remove("Register.txt");
			rename("Temp2.txt", "Register.txt");
		}

		void updateuser() {
			string deleteline;
			string line;

			ifstream fin;
			fin.open("Register.txt");
			ofstream temp;
			temp.open("temp_update.txt");
			cout << "Enter Name of user to update: ";
			cin >> deleteline;
			while (getline(fin,line)) {
				size_t pos=line.find("\t");
				if(line.substr(0,pos).compare(deleteline)==0) {
					cout<<"User Name:"<<endl;
					cin.ignore();
					getline(cin,un);
					cout<<"User password:"<<endl;

					getline(cin,passw);
					cout<<"Email:"<<endl;

					getline(cin,Email);
					cout<<"Date of joining:"<<endl;

					getline(cin,doj);
					temp<<line.substr(0,pos)<<"\t"<<un<<"\t"<<passw<<"\t"<<Email<<"\t"<<doj<<"\n";
				} else {
					temp<<line<<endl;
				}
			}
			fin.close();
			temp.close();
			remove("Register.txt");
			rename("temp_update.txt", "Register.txt");
		}
};

class stock { // has a product relation
		char name[20];
		float pr;
		int quant;
		int id;

	public:
		void get() {
			cout<<"ID:";
			cin >> id;
			cin.ignore();
			cout<<"Name of Product: ";
			cin.getline(name,20);
			cout<<"Price: ";
			cin>>pr;
			cout<<"Quaintity: ";
			cin>>quant;
		}
		float getprice() {
			return pr;
		}
		void show() {
			cout<<id << "\t\t\t\t" <<name<<"\t\t\t\t"<<quant<<"\t\t\t\t"<<pr<<endl;
		}
		void show2() {
			cout<<name<<"\t\t\t\t"<<pr<<endl;
		}
		bool stchk(char nm[30]) {
			if(strcmp(name,nm)==0) {
				return true;
			} else
				return false;
		}
		void withd(int qty) {
			if(quant>=qty) {
				quant-=qty;
				cout<<"\n\nStock Updated.\n";
				cout<<"\n\n\t\tHAPPY SHOPPING...";
			} else
				cout<<"\n\nInsufficient stock";
			getch();
		}
		void refil(int qty) {
			quant+=qty;
			cout<<"\n\nStock updated.";
			getch();
		}
		void update(float price) {
			pr=price;
			cout<<"\n\nPrice updated.";
			getch();
		}
};
class user { //abstract class
	public:
		virtual void display()=0;
		registration r;
		stock st;			 
};
class password {
	private:
		char pass2[10];
		int i,j;
		void Password() {
			system("cls");
			cout<<"\n\n\n\n\t\tEnter Password:";

			for(int z=0; z<4; z++) {
				pass2[z]=getch();
				system("cls");
				cout<<"\n\n\n\n\t\tEnter Password:";
				for(i=1; i<=(z+1); i++) {
					cout<<"*";
				}
			}

		}
		friend class admin;
};
class customer:public user {
		string usrnam,passwor;
		float b;
		char temp[20];
		int qty;
	public:
		bool signin() {
			cout<<"Enter user name:"<<endl;
			cin.ignore();
			getline(cin,usrnam);
			cout<<"Enter your password: "<<endl;
			getline(cin,passwor);
			fin.open("Register.txt");
			while (!fin.eof()) {
				string line;
				fin >> line;
				if(line==usrnam) {
					fin >> line;
					if(line==passwor)
						return true;
					else
						return false;
				}
			}
			return false;
		}
		void reg() {
			r.userprofile();
		}
		void buyitem();
		void display() {
			cout<<"\t\tYOUR BILL" <<"\nITEM:" << temp <<"\nQUANTITY:" << qty <<"\nBILL: "<<b<< endl ;
		}
		void display(int ) {
			int i=1;
			cout<<"\n==================================================================";
			cout<<"\n\n=================\tSTOCK ITEMS\t==================";
			cout<< "\n\nNAME OF PRODUCT" <<"\t\t\tPRICE"<<endl;
			cout<<"\n\n============================================================\n";
			fin.open("hardware.txt");
			while(!fin.eof()) {
				fin.read((char*)&st,sizeof(st));
				if(!fin.eof()) {
					if(fin.tellg()<0) {
						i=0;
						break;
					}
					st.show2();
				}
			}
			if(i==0) {
				cout<<"\n\n\t\t\t!!Empty Stock!!"<<endl;;
				getch();
			}
			fin.close();
		}
};
void customer::buyitem() {
	int i,j=0,joke=0;
	if(j==0) {
		cout << "Name of product to buy:" << endl;
		cin.ignore();
		cin.getline(temp,19);
		cout << "How much quaintity do you want to buy:" << endl;
		cin >> qty;
		fout.open("temp.txt");
		fin.open("hardware.txt");
		while(!fin.eof()) {
			fin.read((char*)&st,sizeof(st));
			if(!fin.eof()) {
				if(st.stchk(temp)) {
					st.withd(qty);
					joke++;
					fout.write((char*)&st,sizeof(st));

					b=st.getprice()*qty;
				} else
					fout.write((char*)&st,sizeof(st));
			}
		}
		if(joke==0)
			cout << "Item not found..." << endl;

		fin.close();
		fout.close();
		remove("hardware.txt");
		rename("temp.txt","hardware.txt");
		getch();
	}
}
class admin:public user { // has a password
		int i=0,j=0;
	public:
		void delete_cust() {
			registration r;
			r.deleteuser();
		}
		void update_cust() {
			registration r;
			r.updateuser();
		}
		void update_price();
		void addnew();
		void display();
		void refill();
		void remove1();
		bool check(password &p)	{
			p.Password();
			if(!strcmp(p.pass2,"damn"))
				return true;
			else
				return false;
		}
		void begin(password &p) {
			for(i=0; i<3; i++) {
				if(check(p)) {
					j=1;
					break;
				}

			}
			if(j==1) {
				while(i!=6) {
					system("cls");
					cout<<"===============";
					cout<<"\n\n\t\t\tMAIN MENU\n1. Display stock\n2. Refill\n3. Add new product\n4. REMOVE\n5. update price\n6. Delete customer\n7. Update customer\n8. Exit";
					cout<<"\n\n\n=======END OF MENU==========";
					cout<<"\n\n Select any Option:";

					cin>>i;
					if(i==1) {
						system("cls");
						admin::display();
						system("pause");

					} else if(i==2) {
						system("cls");
						admin::display();
						system("pause");
						system("cls");
						admin::refill();
						getch();
					} else if(i==3) {
						system("cls");
						admin::display();
						system("pause");
						system("cls");
						admin::addnew();
						getch();
					} else if(i==4) {
						system("cls");
						admin::display();
						system("pause");
						system("cls");
						admin::remove1();
						getch();
					} else if(i==5) {
						system("cls");
						admin::display();
						system("pause");
						system("cls");
						admin::update_price();
						getch();
					} else if(i==6) {
						system("cls");
						admin::delete_cust();
						getch();
						system("cls");
					} else if(i==7) {
						system("cls");
						admin::update_cust();
						getch();
						system("cls");
					} else if(i==8) {
						system("cls");
						exit(0);
						system("cls");
					} else
						cout << "incorrect value please try again" << endl;
				}
			} else {
				cout << "password was incorrect" << endl;
			}

		}


};
void admin::update_price() {
	int j=0,joke=2;
	if(j==0) {
		char temp[20];
		int qty;
		cout << "Name of product:" << endl;
		cin.ignore();
		cin.getline(temp,19);
		cout << "NEW PRICE:" << endl;
		cin >> qty;
		fout.open("temp.txt");
		fin.open("hardware.txt");
		while(!fin.eof()) {
			fin.read((char*)&st,sizeof(st));
			if(!fin.eof()) {
				if(st.stchk(temp)) {
					st.update(qty);
					cout<<"\n\n\t\tstock updated...";
					joke++;
					fout.write((char*)&st,sizeof(st));
				} else
					fout.write((char*)&st,sizeof(st));
			}
		}
		if(joke==0)
			cout << "Item not found..." << endl;

		fin.close();
		fout.close();
		remove("hardware.txt");
		rename("temp.txt","hardware.txt");
		getch();
	}
}
void admin::addnew() {
	system("cls");

	cout<<"\nEnter the No. of Products do you want to add:";
	cin>>n;
	if (n!=0) {

		int j,l,sum=0;
		fout.open("hardware.txt",ios::app);
		for(i=0; i<n; i++) {
			cout<<"\n\nInput the Data of Item...\n\n";
			st.get();
			fout.write((char*)&st,sizeof(st));
			cout<<"\n\nitem updated";
		}
		cout<<"\n\nStock Updated!!";
		fout.close();
		cin.get();
		system("cls");
	}

}
void admin::display() {
	int i=1;
	cout<<"\n==================================================================";
	cout<<"\n\n=================\tSTOCK ITEMS\t==================";
	cout<<"\n\n==================================================================\n";
	cout<<"\n\nID\tPARTICULARS\tSTOCK AVAILABLE\t\t\t PRICE";
	cout<<"\n\n============================================================\n";
	fin.open("hardware.txt");
	cout<<"ID"<< "\t\t\t\tNAME OF PRODUCT" <<"\t\t\tQUAINTITY"<<"\t\t\tPRICE"<<endl;
	while(!fin.eof()) {
		fin.read((char*)&st,sizeof(st));
		if(!fin.eof()) {
			if(fin.tellg()<0) {
				i=0;
				break;
			}
			st.show();
		}
	}
	if(i==0) {
		cout<<"\n\n\t\t\t!!Empty Stock!!"<<endl;;
		getch();
	}
	fin.close();

}
void admin::refill() {
	int j=0,joke=0;
	if(j==0) {
		char temp[20];
		int qty;
		cout << "Name of product:" << endl;
		cin.ignore();
		cin.getline(temp,19);
		cout << "How much quaintity do you want to add:" << endl;
		cin >> qty;
		fout.open("temp.txt");
		fin.open("hardware.txt");
		while(!fin.eof()) {
			fin.read((char*)&st,sizeof(st));
			if(!fin.eof()) {
				if(st.stchk(temp)) {
					st.refil(qty);
					cout<<"\n\n\t\tstock updated...";
					joke++;
					fout.write((char*)&st,sizeof(st));
				} else
					fout.write((char*)&st,sizeof(st));
			}
		}
		if(joke==0)
			cout << "Item not found..." << endl;

		fin.close();
		fout.close();
		remove("hardware.txt");
		rename("temp.txt","hardware.txt");
		getch();
	}
}
void admin::remove1() {
	system("cls");
	int i=0;
	char temp[20];
	cout<<"\n\nName of product to Remove:";
	cin.ignore();
	cin.getline(temp,19);
	fout.open("temp.txt");
	fin.open("hardware.txt");
	while(!fin.eof()) {
		fin.read((char*)&st,sizeof(st));
		if(!fin.eof())
			if(st.stchk(temp)) {
				st.show();
				cout<<"\n\n\t\tRecord deleted...";
				i++;
			} else
				fout.write((char*)&st,sizeof(st));
	}
	if(i==0)
		cout<<"\n\n  Record not found!!";
	fin.close();
	fout.close();
	remove("hardware.txt");
	rename("temp.txt","hardware.txt");
	getch();
}
int main() {
	int i,j;
	system("cls");
	cout<<"\n\n\t||=============== WELCOME  TO  Hardware  Inventory  Store ==============||";
	getch();
	system("cls");
	cout<<"\n\t\t   Hardware Inventory Store\n";
	cout<<"====================================================";
	cout<<"\n\n\t\t   1. Admin Menu";
	cout<<"\n\n\t\t   2. Customer Menu";
	cout<<"\n\n====================================================\n";
	cout<<"\n\n Select any Option:";
	cin>>j;
	if(j==1) {
		system("cls");
		password p;
		admin a;
		a.begin(p);
	} else if(j==2) {
		int k=0;
		customer c;
		system("cls");
		cout<<"Customer Portal"<<endl;
		cout<<"1. Customer Registration"<<endl;
		cout<<"2. Existing Customer"<<endl;
		cin>>k;
		system("cls");
		switch (k) {
			case 1:
				c.reg();
				cout << "registration successful " << endl;
				getch();
				return main();
				break;

			case 2:
				if(c.signin()) {
					c.display(0);
					getch();
					system("cls");
					c.buyitem();
					c.display();
					break;
				}
			default :
				cout<<"Incorrect Option";
				break;
		}
	}
	return 0;
}


