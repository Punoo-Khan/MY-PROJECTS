#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <windows.h>
typedef struct books{
char booknam[30];
char issue[10];
int price;
int bookid;
char author[10];
char user[15];
int id;
}books;
struct user{
char name[20];
char pwd[30];
int rollno;
char email[50];
}new;
char admin[20]={"bete"};
void password();
void adminmenu();
void usermenu(int roll,char nam[20]);
void request(int roll,char nam[20]);
void addbook();
void searchbook();
void searchbook3();
void searchbook2();
void list();
void deletebook();
void issuebook(char name[],char author[]);
void display();
void gotoxy(int x, int y)
{
     COORD coord;
     coord.X =x;
     coord.Y =y;
     SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord); 
} ;    
int main()
{
	printf("Library managment system");
//	sleep(100);
    password();
    getch();

}
void password()
{
    system("cls"); 
    char ch,pwd[10],name2[10];
    int i=0,j,k,y,news;
   
    char intro[50] ="Library managment system ";
    k=strlen(intro);
    printf("\t\t\t");
    for(j=0;j<k;j++)
    {
        printf("%c",intro[j]);
           Sleep(100);
    }
   printf("\n\nare you Admin or user\?\nSign up if you are new(write register): ");
   scanf("%s",name2);
   k=strcmp(name2,"admin");
   y=strcmp(name2,"user");
   news=strcmp(name2,"register");
   if(k==0)
   {
     printf("welcome admin\n");
     printf("write password: ");
     while(ch!=13)//13 for enter
     {
         ch=getch();
         if(ch!=13 && ch!=8)//8 for backspace
         {
             printf("*");
             pwd[i]=ch;
             i++;
         }
     }
     pwd[i]='\0';
    
     if(strcmp(pwd,admin)==0)
     {
          printf("welcome admin");
           adminmenu();                   
     }
     else
     {
         printf("\a\nlook at little hacker jr. wanna hack\n");
     }   
    }
    if(y==0)
    {
        
        printf("welcome user\n"); char ch,line[100],password2[20],com[20]="punoo";
        printf("write your user name: ");
        int i=0,z=0,count=1,lol=0;
        scanf("%s",line);
         printf("write your password: ");    
         scanf("%s",password2);
        FILE *inf;
        struct user np;
        inf=fopen("usernameandpwd.txt","r");
        if(inf==NULL)
        {
          fprintf(stderr,"error is there2");  
        }
        else
        while(fread(&np,sizeof(struct user),1,inf))
        {    
            i=strcmp(np.name,line);
            z=strcmp(np.pwd,password2);                     
         if(i==0&&z==0)
         {
             printf("welcome %s",np.name); getch();
             usermenu(np.rollno,np.name);
             count=0;
         }
        }
        if(count!=0)
        {
             printf("\aGonna put some dirt in your eye ");
        }
        fclose(inf);
    }
    if(news==0)
    {
        char con[50];
        int a=1;
    FILE *fptr;
    fptr=fopen("usernameandpwd.txt","a");
    if(fptr==NULL)
    {
          printf("error is there");        
    }
    
        printf("write your user name: "); scanf("%s",new.name);
        //fflush(stdin);
        printf("write your password: ");     scanf("%s",new.pwd);
        // printf("confirm password: ");         
        printf("write your roll no: ");     scanf("%d",&new.rollno);
        printf("write your gmail: ");     scanf("%s",new.email);
        fwrite(&new,sizeof(struct user),1,fptr);
        if(fwrite!=0)
        {
            printf("contents of file written successfully");
            getch();        
        }             
        else
        {
            printf("error ");
        }
        
        exit(0);
    }    
}
void adminmenu()
{

  int a;
  while(a!=7)
  {
    system("cls");           
  gotoxy(20,3);
  printf("\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 MAIN MENU\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
  gotoxy(20,5);
  printf("\xDB\xDB\xDB\xDB\xB2 1. ADD BOOKS");
  gotoxy(20,7);
  printf("\xDB\xDB\xDB\xDB\xB2 2. DELETE BOOKS");
  gotoxy(20,9);
  printf("\xDB\xDB\xDB\xDB\xB2 3. SEARCH BOOKS");
  gotoxy(20,11);
  printf("\xDB\xDB\xDB\xDB\xB2 4. VEIW BOOK LIST");
  gotoxy(20,13);
  printf("\xDB\xDB\xDB\xDB\xB2 5. ISSUE BOOK");                
  gotoxy(20,15);
  printf("\xDB\xDB\xDB\xDB\xB2 6. VIEW REQUEST LIST");
  gotoxy(20,17);
  printf("\xDB\xDB\xDB\xDB\xB2 7. CLOSE APPLICATION");
  gotoxy(20,19);
  printf("Enter your choice: ");
  scanf("%d",&a);	
  switch(a)
  {
      case 1: addbook();
       getch();break;
      case 2: deletebook();break;
      case 3: searchbook(); break;
      case 4: display(); getch();break;
        case 5: searchbook2(); getch();break;
      case 6:list();
	   break;
      case 7:printf("thank you for checking");  exit(0);
      default: 
      printf("invalid choice"); Sleep(1000);   adminmenu(); 

  }
  }   
}
void usermenu(int roll,char nam[20])
{
     int a;
     while(a!=3){
  system("cls");
  gotoxy(20,3);
  printf("\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2 MAIN MENU\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2\xB2");
  gotoxy(20,5);
  printf("\xDB\xDB\xDB\xDB\xB2 1. SEARCH BOOKS");
  gotoxy(20,7);
  printf("\xDB\xDB\xDB\xDB\xB2 2. REQUEST FOR ISSUE OF BOOKS");
  gotoxy(20,9);
  printf("\xDB\xDB\xDB\xDB\xB2 3. CLOSE APPLICATION");
   gotoxy(20,11);
  printf("Enter your choice: ");
  scanf("%d",&a);
  switch(a)
  {
      case 1: searchbook3();
      break;
      case 2: request(roll,nam);   break;
      case 3:printf("thank you for checking"); exit(0);
      default: 
      printf("invalid choice"); Sleep(1000);   usermenu( roll, nam); 
  }
}
}
void request(int roll,char nam[20])
{
    char name[30],author[20];
    // char issue1[10]="issued",issue[10],user[20],booknam;
     //int id,price,bookid;
     char issue[10]="issued",waste[30];
    int i,j,k,num=0;
    static int count=0;
    books s1;
    FILE *fp,*lol,*fptr;
    fp=fopen("books.txt","r");
    lol=fopen("issue.txt","w");
    printf("enter the name of the book: ");
    scanf("%s",name);
    printf("enter the author of the book: ");
    scanf("%s",author);
     while(fread(&s1,sizeof(books),1,fp))
     {
         num++;
         i=strcmp(author,s1.author);
         j=strcmp(name,s1.booknam);
         k=strcmp(s1.issue,"avaliable");                                
         if(i==0&&j==0&&k==0)
         {
             strcpy(s1.issue,"issued");
             strcpy(s1.user,nam);
             s1.id=roll;
             printf("%s\n",s1.user);
             fwrite(&s1,sizeof(books),1,lol);
             printf("your requested has been added\n");
              issuebook(name,author);
              getch();
             count=1; 
             fptr=fopen("list.txt","w");
             strcpy(waste,s1.booknam);
             strcat(waste,"is requested");
             printf("%s",waste);
             fprintf(fptr,"%s",waste);
             fclose(fptr);
         }
         }
        if(count==0)
         {
             printf("the book is currently unavaliable\n");
             count=2;
              getch();
     }
   fclose(fp);
   fclose(lol);
  
}

void issuebook(char name[],char author[])
{    
    int i,j,k,MAX=256;
    char str[MAX],temp[]="temp.txt",fname[]="books.txt";
    books s1;
    FILE *fp,*lol; 
    lol=fopen(temp,"w");
    fp=fopen(fname,"r");
    while(fread(&s1,sizeof(books),1,fp))
    {
        i=strcmp(author,s1.author);
        j=strcmp(name,s1.booknam);
        if(j!=0&&i!=0)
        {
            fwrite(&s1,sizeof(books),1,lol);
        }
    }
    fclose(fp);
    fclose(lol);
    lol=fopen(temp,"r");
    fp=fopen(fname,"w");
//    remove("books.txt");
//    rename("books.txt","temp.txt");
//    if(rename("books.txt","C:\\Users\\waseemshaikhcomputer\\Pictures\\mdcat\\temp.txt")==0)
//    {
//       printf("success");
//    }
//    else
//       fprintf(stderr,"System error %d : %s\n",errno,strerror(errno));
       while(fread(&s1,sizeof(books),1,lol))
       {
            fwrite(&s1,sizeof(books),1,fp);
       }
        fclose(fp);
        fclose(lol);
        getch();
}
void searchbook2()
{
       FILE *fp1, *fp2;
      char fname1[50],fname2[50],c;
      printf("Enter filename to open for reading : ");
      scanf("%s", fname1);
      // Open one file for reading
      fp1 = fopen(fname1, "r");
      if (fp1 == NULL)
     {
            printf("%s file does not exist..", fname1);
            exit(0);
      }
      printf("\nEnter filename to append the content : ");
      scanf("%s", fname2);
      // Open another file for appending content
      fp2 = fopen(fname2, "a");
      if (fp2 == NULL)
      {
            printf("%s file does not exist...", fname2);
            exit(0);
      }
      // Read content from file
      c = fgetc(fp1);
      while (c != EOF)
      {
            fputc(c,fp2);
            c = fgetc(fp1);
      }
      printf("\nContent in %s appended to %s", fname1,fname2);
      fclose(fp1);
      fclose(fp2);
        getch();
}     
void addbook()
{
    books *s; 
    int num,i;
    FILE *fptr;
    fptr=fopen("books.txt","a");
    printf("how many books you want to add: ");
    scanf("%d",&num);
    s = (books*)calloc(num,sizeof(books));
    for(i=0;i<num;i++)
    {
        printf("Enter the id of the book: ");          scanf("%d",&s[i].bookid);              
        fflush(stdin);
        printf("Enter the name of the book: ");      scanf("%[^\n]s",s[i].booknam);
        printf("Enter the name of the author(capital letters): ");     scanf("%s",s[i].author);
        printf("Enter the price of the book: ");       scanf("%d",&s[i].price);
        printf("book is issued or avaliable : ");          scanf("%s",s[i].issue);
        printf("if issued write roll no else 000 : ");          scanf("%d",&s[i].id);
        printf("if issued write name of student else NULL : ");          scanf("%s",s[i].user);
        fwrite(&s[i],sizeof(books),1,fptr); 
    }
    fclose(fptr);
}
void display()
{
    books s1;
    FILE *fp;
    fp=fopen("books.txt","r");
    printf("author\tbook\tprice\tID\tavaliablity\troll no\tissued by");
    while(fread(&s1,sizeof(books),1,fp))
    {
       printf("\n%s\t%s\t%d\t%4d   %5s    %5d    %s",s1.author,s1.booknam,s1.price,s1.bookid,s1.issue,s1.id,s1.user);                         
    }
    fclose(fp);
}
void searchbook()
{
    char saiman[30];
    int count=0;
     books s1;
    FILE *fp;
    fp=fopen("books.txt","r");
    printf("enter the name of the book: ");
    scanf("%[^\n]s",saiman);
    printf("author\tbook\tprice\tID\tavaliablity\troll no\tissued by");
    while(fread(&s1,sizeof(books),1,fp))
    {
        if(strcmp(s1.booknam,saiman)==0)
        {
       printf("\n%s\t%s\t%d\t%4d   %5s    %5d    %s",s1.author,s1.booknam,s1.price,s1.bookid,s1.issue,s1.id,s1.user);                         
        count=1;
        }

    }
    if(count!=1)
    {
        printf("\nsorry record not found");
    }
    fclose(fp);
    getch();
}
void searchbook3()
{
    char saiman[30];
    int count=0;
    books s1;
    FILE *fp;
    fp=fopen("books.txt","r");
    printf("enter the name of the book: ");
    scanf("%[^\n]s",saiman);
    while(fread(&s1,sizeof(books),1,fp))
    {
        if(strcmp(s1.booknam,saiman)==0)
        {
    	printf("author\tbook");
       printf("\n%s\t%s",s1.author,s1.booknam);                         
        count=1;
        }

    }
    if(count!=1)
    {
        printf("\nsorry record not found");
    }
    fclose(fp);
    getch();
}
void deletebook()
{
     int i,j,k,MAX=256;
    char str[MAX],temp[]="temp.txt",fname[]="books.txt";
    books s1;
    FILE *fp,*lol; 
    lol=fopen(temp,"w");
    fp=fopen(fname,"r");
    printf("write the id of the book which you want to be deleted: ");
    scanf("%d",&k);
    while(fread(&s1,sizeof(books),1,fp))
    {
        if(s1.bookid==k)
        i=1;                              
        if(s1.bookid!=k)
        {
            fwrite(&s1,sizeof(books),1,lol);
        }
    }
    fclose(fp);
    fclose(lol);
    lol=fopen(temp,"r");
    fp=fopen(fname,"w");

       while(fread(&s1,sizeof(books),1,lol))
       {
            fwrite(&s1,sizeof(books),1,fp);
       }
        fclose(fp);
        fclose(lol);
        if(i==1)
        printf("deletion successful\n");
        else
        printf("id not found");
        getch();
}
void list()
{
	int count=0;
	char s1[30];
	FILE *fptr;
	fptr=fopen("list.txt","r");
	while(fread(&s1,sizeof(books),1,fptr)!=EOF||count==0)
	{
		fscanf(fptr,"%s",s1);
		printf("%s ",s1);
		count++;
		Sleep(1000);
	}
	fclose(fptr);
	 
}
